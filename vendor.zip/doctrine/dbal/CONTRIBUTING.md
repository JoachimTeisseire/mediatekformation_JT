Doctrine has [general contributing guidelines][contributor workflow], make
sure you follow them.

[contributor workflow]: https://www.doctrine-project.org/contribute/index.html
